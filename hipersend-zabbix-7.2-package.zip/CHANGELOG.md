# Changelog

## v2.0.0 — 2025-09-09
- Compatibilidade com Zabbix **7.2+** (HttpRequest; remoção de CurlHttpRequest).
- Novo script `scripts/hipersend-zabbix7.js`.
- Suporte a envio para **número** e **grupo** (endpoints dedicados).
- Conversão automática **HTML → WhatsApp**.
- Documentação atualizada e troubleshooting.
